import React from 'react';

import './app.scss';

export const App = () => {
  /*
   * Replace the elements below with your own.
   *
   * Note: The corresponding styles are in the ./app.scss file.
   */
  return <div className="app"></div>;
};

export default App;
