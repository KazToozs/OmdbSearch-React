module.exports = {
  projects: ['<rootDir>/apps/react-app'],
};
